---
name: ForkLab
colors:
  surface: '#131313'
  surface-dim: '#131313'
  surface-bright: '#3a3939'
  surface-container-lowest: '#0e0e0e'
  surface-container-low: '#1c1b1b'
  surface-container: '#201f1f'
  surface-container-high: '#2a2a2a'
  surface-container-highest: '#353534'
  on-surface: '#e5e2e1'
  on-surface-variant: '#bbc9cf'
  inverse-surface: '#e5e2e1'
  inverse-on-surface: '#313030'
  outline: '#869399'
  outline-variant: '#3c494e'
  surface-tint: '#5bd4ff'
  primary: '#9fe2ff'
  on-primary: '#003544'
  primary-container: '#00cdff'
  on-primary-container: '#005369'
  inverse-primary: '#006781'
  secondary: '#adc6ff'
  on-secondary: '#002e6a'
  secondary-container: '#0566d9'
  on-secondary-container: '#e6ecff'
  tertiary: '#ffcdc9'
  on-tertiary: '#680009'
  tertiary-container: '#ffa69e'
  on-tertiary-container: '#9d0013'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#baeaff'
  primary-fixed-dim: '#5bd4ff'
  on-primary-fixed: '#001f29'
  on-primary-fixed-variant: '#004d62'
  secondary-fixed: '#d8e2ff'
  secondary-fixed-dim: '#adc6ff'
  on-secondary-fixed: '#001a42'
  on-secondary-fixed-variant: '#004395'
  tertiary-fixed: '#ffdad6'
  tertiary-fixed-dim: '#ffb3ad'
  on-tertiary-fixed: '#410003'
  on-tertiary-fixed-variant: '#930011'
  background: '#131313'
  on-background: '#e5e2e1'
  surface-variant: '#353534'
typography:
  h1:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
    letterSpacing: -0.02em
  h2:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 24px
    letterSpacing: -0.01em
  body-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  body-sm:
    fontFamily: Inter
    fontSize: 13px
    fontWeight: '400'
    lineHeight: 18px
  label-caps:
    fontFamily: Space Grotesk
    fontSize: 11px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.05em
  mono-code:
    fontFamily: JetBrains Mono
    fontSize: 13px
    fontWeight: '400'
    lineHeight: 20px
  mono-label:
    fontFamily: JetBrains Mono
    fontSize: 11px
    fontWeight: '500'
    lineHeight: 14px
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  unit: 4px
  container-padding: 16px
  gutter: 12px
  component-gap-xs: 4px
  component-gap-sm: 8px
  component-gap-md: 16px
---

## Brand & Style

This design system is engineered for high-density technical environments where speed of information processing is paramount. The aesthetic is **Modern Technical**, moving away from "soft" consumer SaaS trends in favor of a high-fidelity, operational look that feels like a mission control center. 

The atmosphere is serious and live, emphasizing real-time execution over static marketing. Visual interest is derived from technical evidence—logs, code snippets, and performance metrics—rather than illustrations or decorative gradients. The style utilizes a **Low-Contrast / High-Precision** approach, where depth is created through subtle border variations and monochromatic layering rather than heavy shadows.

## Colors

The palette is anchored in deep, "ink-trap" blacks and charcoals to minimize eye strain during long sessions. The primary accent is a vibrant, electric cyan (#00cdff), providing a high-energy and modern visual signal for active states, primary actions, and core brand elements.

- **Backgrounds:** Use `#050505` for the main workspace and `#0B0B0B` for elevated cards and sidebars.
- **Accents:** The primary color (#00cdff) should be used for primary buttons and high-level structural identification, conveying cutting-edge performance and clarity.
- **Statuses:** Use functional colors strictly for operational states: Blue (#3B82F6) for 'Running' or 'Informational', and Red (#c1121f) for 'Failed' or 'Critical' states.
- **Borders:** A consistent `#222222` is used for all structural containment.

## Typography

This design system utilizes a dual-font strategy to distinguish between UI orchestration and technical data.

- **Inter:** The primary workhorse for the interface. It should be used for navigation, settings, and general body text. It is chosen for its exceptional legibility at small sizes.
- **JetBrains Mono:** Used for all "technical evidence." This includes log streams, terminal outputs, file paths, and environment variables.
- **Space Grotesk:** Reserved for secondary labels and headers that require a slightly more "engineered" feel without sacrificing readability.

All typography should lean towards high-density settings (smaller font sizes with tighter line heights).

## Layout & Spacing

The layout philosophy follows a **Fixed-Fluid Hybrid** model. Navigation and sidebar panels are fixed-width to maintain terminal consistency, while the main viewport fluidly expands to show more log columns or code area.

- **Density:** We utilize a 4px base grid. Spacing between related elements (like a label and an input) should be 4px or 8px.
- **Grid Background:** Main work surfaces should feature a subtle dotted grid pattern (color: `#1A1A1A`, spacing: 16px) to reinforce the "under construction" or "operational" feel.
- **Margins:** Use 16px margins for main containers and 12px gutters for internal card layouts.

## Elevation & Depth

This design system avoids traditional drop shadows. Depth is conveyed through **Tonal Layering** and **Thin Borders**.

1.  **Level 0 (Base):** `#050505` - The fundamental background.
2.  **Level 1 (Surface):** `#0B0B0B` - Cards, sidebars, and panels. These must have a 1px border of `#222`.
3.  **Level 2 (Interaction):** `#161616` - Hover states and active selections.
4.  **Level 3 (Overlay):** `#1A1A1A` - Tooltips and dropdown menus, utilizing a slightly brighter border (`#333`) to separate them from the surface.

For critical overlays, a subtle backdrop blur (4px) can be applied to the layer behind the modal to maintain focus on the technical task.

## Shapes

The design system uses a **Soft Geometry** approach. While the atmosphere is technical, slight rounding prevents the UI from feeling dated or overly aggressive.

- **Standard Radius:** 4px (`0.25rem`) for cards, buttons, and main UI panels.
- **Small Radius:** 2px for smaller components like chips, tags, and checkboxes.
- **Inner Radius:** When nesting elements, the inner radius should be reduced to maintain visual concentricity with the outer container.

## Components

### Buttons
- **Primary:** Background `#00cdff`, Text `#000000`. High contrast, bold, electric.
- **Secondary:** Background `transparent`, Border `#222`, Text `#FFF`. 
- **Ghost:** Background `transparent`, Text `#888`. Highlight to white on hover.

### Inputs & Terminal
- **Input Fields:** Dark background (`#050505`), 1px border (`#222`). Focus state uses a 1px `#00cdff` border with no outer glow.
- **Terminal Panels:** Always use JetBrains Mono. Use a slightly darker background than the surface it sits on to create a "well" effect.

### Data Displays
- **Status Chips:** Small, pill-shaped. Use a low-opacity background of the status color (e.g., Red/Tertiary at 10% opacity) with a solid 1px border of the same color and white text.
- **Execution Logs:** High-density rows (24px height). Alternating row highlights are not used; instead, use subtle hover states to indicate line focus.
- **Breadcrumbs:** Use monospaced font for file paths, separated by a `/` in a muted `#444` color.

### Navigation
- Vertical sidebars with collapsed icons. Icons should be stroke-based, 1.5px thickness, and monochromatic until hovered. Active navigation states use the primary cyan (#00cdff) color.